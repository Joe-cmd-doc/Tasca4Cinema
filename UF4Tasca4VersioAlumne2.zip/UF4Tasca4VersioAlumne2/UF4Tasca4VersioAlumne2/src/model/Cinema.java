package model;

import java.util.Date;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.List;

public class Cinema implements ICinema {

    private List<ITheater> theaters;
    private List<IMovie> movies;
    private List<ISession> sessions;

    public Cinema() {
        this.theaters = new ArrayList<>();
        this.movies = new ArrayList<>();
        this.sessions = new ArrayList<>();
    }

    @Override
    public ITheater[] getTheaters() {
        return theaters.toArray(new ITheater[0]);
    }

    @Override
    public IMovie[] getMovies() {
        return movies.toArray(new IMovie[0]);
    }

    @Override
    public ISession[] getSessions() {
        return sessions.toArray(new ISession[0]);
    }

    @Override
    public void addTheater(int capacity) {
        ITheater theater = new Theater(capacity);
        theaters.add(theater);
    }

    @Override
    public void deleteTheater(int id) throws NoSuchElementException {
        ITheater theater = getTheater(id);
        theaters.remove(theater);
    }

    @Override
    public void updateTheater(int id, int newCapacity) throws NoSuchElementException {
        ITheater theater = getTheater(id);
        theater.setCapacity(newCapacity);
    }

    @Override
    public void addMovie(String name, String author, int duration) {
        IMovie movie = new Movie(name, author, duration);
        movies.add(movie);
    }

    @Override
    public void deleteMovie(int id) throws NoSuchElementException {
        IMovie movie = getMovie(id);
        movies.remove(movie);
    }

    @Override
    public void updateMovie(int id, String newName, String newAuthor, int newDuration) throws NoSuchElementException {
        IMovie movie = getMovie(id);
        movie.setName(newName);
        movie.setAuthor(newAuthor);
        movie.setDuration(newDuration);
    }

    @Override
    public void addSession(int idTheater, int idMovie, Date date) throws NoSuchElementException {
        ITheater theater = getTheater(idTheater);
        IMovie movie = getMovie(idMovie);
        ISession session = new Session(theater, movie, date);
        sessions.add(session);
    }

    @Override
    public void deleteSession(int id) throws NoSuchElementException {
        ISession session = getSession(id);
        sessions.remove(session);
    }

    @Override
    public void updateSession(int id, Date newDate) throws NoSuchElementException {
        ISession session = getSession(id);
        session.setDate(newDate);
    }

    @Override
    public void bookSeat(int idSession, int seatNumber) throws SeatAlreadyBookedException {
        ISession session = getSession(idSession);
        session.book(seatNumber);
    }

    private ITheater getTheater(int id) throws NoSuchElementException {
        for (ITheater theater : theaters) {
            if (theater.getId() == id) {
                return theater;
            }
        }
        throw new NoSuchElementException("Theater not found.");
    }

    private IMovie getMovie(int id) throws NoSuchElementException {
        for (IMovie movie : movies) {
            if (movie.getId() == id) {
                return movie;
            }
        }
        throw new NoSuchElementException("Movie not found.");
    }

    private ISession getSession(int id) throws NoSuchElementException {
        for (ISession session : sessions) {
            if (session.getId() == id) {
                return session;
            }
        }
        throw new NoSuchElementException("Session not found.");
    }

}

