package model;

public interface IMovie {

	int getId();
	void setId(int id);
	String getName();
	void setName(String name);
	String getAuthor();
	void setAuthor(String author);
	int getDuration();
	void setDuration(int duration);
}
