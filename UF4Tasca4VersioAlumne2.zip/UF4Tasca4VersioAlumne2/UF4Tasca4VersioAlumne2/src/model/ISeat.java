package model;

public interface ISeat {

	void book() throws SeatAlreadyBookedException;
}
