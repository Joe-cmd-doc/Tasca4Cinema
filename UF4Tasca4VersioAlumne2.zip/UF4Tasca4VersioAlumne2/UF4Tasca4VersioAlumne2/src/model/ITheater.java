package model;

public interface ITheater {

	void setId(int id);
	int getId();
	void setCapacity(int capacity);
	int getCapacity();
	
	
}
